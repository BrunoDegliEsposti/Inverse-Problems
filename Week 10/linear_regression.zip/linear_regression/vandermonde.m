function v = vandermonde(as, xs)
    % Make sure that as is a column vector 
    if size(as,2) > 1
    	as = as.';
    end
    % Make sure that xs is a column vector
    if size(xs, 2) > 1
        xs = xs.';
    end
    
    N = length(as);
    v = zeros(length(xs), N);
    for k=0:N-1
        v(:, k+1) = xs.^k;
    end
end