function ys = evalPolynomial(as, xs)
    v = vandermonde(as, xs);  
    if size(as,2) > 1
    	as = as.';
    end
    ys = v*as;    
end



    