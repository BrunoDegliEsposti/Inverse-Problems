function data = generateData(as, xs, gamma)
    ys = evalPolynomial(as, xs);
    data = ys + gamma*normrnd(0, 1, length(ys), 1);
end