clear 
close all

% measurement noise standard deviation
gamma = 0.05;

xs_plot = 0:0.01:1;
%fnc_test = @(x) sin(2*pi*x);
as = [1, -1, 0.5, 0, 0, -0.2];
N_poly = length(as);

% make shorthand for this polynomial
fnc_true = @(x) evalPolynomial(as, x);

xs_data = [0.01, 0.1, 0.6, 0.65, 0.7, 0.72, 0.8, 0.9];
ys_data = generateData(as, xs_data, gamma);
N_data = length(ys_data);


figure();
plot(xs_plot, fnc_true(xs_plot))
hold on;
plot(xs_data, ys_data, 'r.', 'markersize', 20);


A = vandermonde(as, xs_data);
Sigma = 50*diag(1./sqrt(1:(N_poly)));
Gamma = gamma^2*eye(N_data);

% Kalman gain
K = Sigma*A.'*inv(Gamma+A*Sigma*A.');
mean_post = K*(ys_data);
Cov_post = Sigma - K*A*Sigma;
Cov_post = (Cov_post + Cov_post.')/2;

N_samples = 500;
samples = mvnrnd(mean_post, Cov_post, N_samples);
figure();
hold on;
for k=1:N_samples
    fnc = @(x) evalPolynomial(samples(k, :), x);
    p = plot(xs_plot, fnc(xs_plot), 'k');
    p.Color(4) = 0.05;
end

fnc_mean = @(x) evalPolynomial(mean_post, x);
p = plot(xs_plot, fnc_mean(xs_plot), 'k--', 'LineWidth', 3);

plot(xs_plot, fnc_true(xs_plot), 'b')
plot(xs_data, ys_data, 'r.', 'markersize', 20);