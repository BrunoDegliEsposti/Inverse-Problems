# README

The provided code can be run in matlab & octave.
### MATLAB

### Octave
The octave-communication package is required to run the code. 

* octave
* octave-control
* octave-signal (requires octave-control)
* octave-communications (requires octave-signal)

