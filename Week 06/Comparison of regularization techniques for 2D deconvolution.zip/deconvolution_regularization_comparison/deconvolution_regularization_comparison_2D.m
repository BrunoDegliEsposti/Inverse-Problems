% author: Daniel Tenbrinck
% date: 17.11.2019

%% prepare work environment

% clean up
clc; clear; close all;

% add relevant subfolders to path
addpath('./functions');


%% load a test image

% read the test image
u = double(imread('cameraman.tif'));

% visualize test image
figure; imagesc(u); colormap('gray'); axis image;
title('Original image');

% specify parameters of Gaussian kernel
k=5; kernelsize = 2*k+1; % size of kernel
sigma = 2; % sqrt variance of kernel

% generate Gaussian kernel and its conjugate operation in Fourier space
[convolutionOperation, convolutionOperation_adjoint, kA] = createGaussianBlurringOperator(size(u),kernelsize,sigma);

% blur image with Gaussian kernel
f = convolutionOperation(u);

% specify noise variance for Gaussian noise
noise_variance = 2;

% add Gaussian noise
f = f + noise_variance * randn(size(u));

% visualize blurred and noisy image
figure; imagesc(f); colormap('gray'); axis image;
title('Image blurred by Gaussian kernel');

pause();


%% Deconvolution with Tikhonov regularization and normal equations

% specify the regularization parameter
alpha = 0.01; %0.01 is reasonable

% initialize identity kernel
identity = zeros(size(u));
identity(1,1) = alpha;

% compute Fourier transform of identity operation
identityOperation = fftn(identity);

% initialize Gaussian filter
kernel = fspecial('gaussian', 11, 2);
gaussianFilter = zeros(size(u));
gaussianFilter(1:size(kernel,1),1:size(kernel,2)) = kernel;

% compute half width of kernel
halfwidth = floor(11/2);

% center the Gaussian kernel
gaussianFilter = circshift(gaussianFilter,-halfwidth,1);
gaussianFilter = circshift(gaussianFilter,-halfwidth,2);

% compute Fourier transform of Gaussian filter
gaussianFilter_Fourier = fftn(gaussianFilter);
gaussianFilter_Conjugated_Fourier = conj(gaussianFilter_Fourier);

% specify operator in Fourier space
operator = gaussianFilter_Conjugated_Fourier .* gaussianFilter_Fourier + identityOperation;

% reconstruct image from f via convolution theorem in Fourier space
reconstruction_Tikhonov_fourier = ifftn(gaussianFilter_Conjugated_Fourier .* fftn(f) ./ operator);

% visualize deconvolution results in 2D
figure; imagesc(reconstruction_Tikhonov_fourier,[0 255]); colormap gray; axis image;
title('Reconstruction with Tikhonov reg. in Fourier space');

% visualize deconvolution results along 1D profile line
figure; 
plot(0:255,f(round(end/2),:), 'b');
hold on;
plot(0:255,reconstruction_Tikhonov_fourier(round(end/2),:), 'r');
plot(0:255,u(round(end/2),:), 'black');
hold off;
xlim([0,255]);
legend('Blurred signal f', 'Reconstructed signal', 'Original signal u');

pause();

%% Deconvolution with generalized Tikhonov regularization in Fourier space

% specify the regularization parameter
alpha = 0.01; %0.01 is reasonable

% initialize Gaussian filter
kernel = fspecial('gaussian', 11, 2);
gaussianFilter = zeros(size(u));
gaussianFilter(1:size(kernel,1),1:size(kernel,2)) = kernel;

% center the Gaussian kernel
gaussianFilter = circshift(gaussianFilter,-halfwidth,1);
gaussianFilter = circshift(gaussianFilter,-halfwidth,2);

% initialize Laplace filter
Laplace = zeros(size(u));
Laplace(1,2) = 1;
Laplace(2,1) = 1;
Laplace(2,2) = -4;
Laplace(2,3) = 1;
Laplace(3,2) = 1;
Laplace = circshift(Laplace,-1,1);
Laplace = circshift(Laplace,-1,2);

% compute Fourier transform of Gaussian filter
gaussianFilter_Fourier = fftn(ifftshift(gaussianFilter));
gaussianFilter_Conjugated_Fourier = conj(gaussianFilter_Fourier);

% compute Fourier transform of Laplace filter
edgeFilter_Laplace = fftn(alpha*Laplace);

% specify operator in Fourier space
operator = gaussianFilter_Conjugated_Fourier .* gaussianFilter_Fourier - edgeFilter_Laplace;

% reconstruct image from f via convolution theorem in Fourier space
reconstruction_genTikhonov_fourier = ifftshift(ifftn(gaussianFilter_Conjugated_Fourier .* fftn(f) ./ operator));

% visualize deconvolution results in 2D
figure; imagesc(reconstruction_genTikhonov_fourier,[0 255]); colormap gray; axis image; 
title('Reconstruction with generalized Tikhonov reg. in Fourier space');

% visualize deconvolution results along 1D profile line
figure; 
plot(0:255,f(round(end/2),:), 'b');
hold on;
plot(0:255,reconstruction_genTikhonov_fourier(round(end/2),:), 'r');
plot(0:255,u(round(end/2),:), 'black');
hold off;
xlim([0,255]);
legend('Blurred signal f', 'Reconstructed signal', 'Original signal u');

pause();


%% Deconvolution with generalized Tikhonov regularization using Conjugated Gradient

% specify the regularization parameter
alpha = 0.01; %0.01 is reasonable

% specify parameters of Gaussian kernel
k=5; kernelsize = 2*k+1; % size of kernel
sigma = 2; % sqrt variance of kernel

% generate Gaussian kernel and its conjugate operation in Fourier space
[convolutionOperation, convolutionOperation_adjoint, kA] = createGaussianBlurringOperator(size(u),kernelsize,sigma);

%%%%% DOESN'T WORK AS EXPECTED!

%filter_x = zeros(3);
%filter_x(2,2) = -1;
%filter_x(2,3) = 1;
%filter_x_inv = rot90(filter_x,2);

%filter_y = zeros(3);
%filter_y(2,2) = -1;
%filter_y(3,2) = 1;
%filter_y_inv = rot90(filter_y,2);

%filter_L = convn(filter_y_inv,filter_x_inv, 'same');
%filter_L_adjoint = convn(filter_y,filter_x, 'same');

%L = @(u) convn(u,filter_L, 'same');
%L_adjoint = @(u) convn(u,filter_L_adjoint, 'same');

%%%%%%

% initialize Laplace filter
Laplace = zeros(3);
Laplace(1,2) = 1;
Laplace(2,1) = 1;
Laplace(2,2) = -4;
Laplace(2,3) = 1;
Laplace(3,2) = 1;
L_Laplace = @(u)  convn(u,Laplace,'same');

% specify maximum number of iterations for conjugated gradient method
maxIts = 1500;

% initialize starting point x0
xk = ones(size(u));

% initialize variables for conjugated gradient method
H = @(u) (convolutionOperation_adjoint(convolutionOperation(u)) - alpha*L_Laplace(u)); % system matrix H=A'*A-alpha*L
b = convolutionOperation_adjoint(f); % right side: A'*f
rk = b - H(xk);
residuals = zeros(1,maxIts);
dk = rk;

% perform conjugated gradient method for solving the equation system Hx=b
for k=1:maxIts
    
    % precalculate z
    z = H(dk);
    
    % determine optimal step width
    alpha_k = (transp(rk(:))*rk(:)) / (transp(dk(:))*z(:));
    
    % compute update
    x_new = xk + alpha_k*dk;
    
    % compute new residual
    r_new = rk - alpha_k*z;
    
    % compute correction coefficient
    beta_k = (transp(r_new(:))*r_new(:)) / (transp(rk(:)) * rk(:));
    
    % determine new A-conjugated vector
    d_new = r_new + beta_k*dk;
    
    % update iterates
    dk = d_new;
    rk = r_new;
    xk = x_new;
    
    % compute norm of residual vector and store it for visualization
    residuals(k) = norm(rk);
    
    % stop conjugated gradient method if norm of residuum is too small
    if norm(rk) < 1e-6
        residuals = residuals(1:k);
        break;
    end
end

% set reconstruction as last iteration
reconstruction_genTikhonov_CG = xk;

% visualize decreasing norm of residual vector
figure; plot(residuals)

% visualize deconvolution results in 2D
figure; imagesc(reconstruction_genTikhonov_CG, [0 255]); colormap gray; axis image;
title('Reconstruction with generalized Tikhonov reg. and CG algorithm');

% visualize deconvolution results along 1D profile line
figure; 
plot(0:255,f(round(end/2),:), 'b');
hold on;
plot(0:255,reconstruction_genTikhonov_CG(round(end/2),:), 'r');
plot(0:255,u(round(end/2),:), 'black');
hold off;
xlim([0,255]);
legend('Blurred signal f', 'Reconstructed signal', 'Original signal u');

pause();

%% Deconvolution with TV-regularization and primal-dual minimization

% specifiy regularization parameter
alpha = 0.3; % 0.05 is reasonable

% perform deconvolution using TV regularization
reconstruction_TV = deconvolution_TV_primaldual(f,kA,alpha);

% visualize deconvolution results in 2D
figure; imagesc(reconstruction_TV); colormap('gray'); axis image; title('Reconstruction with Total variation reg. and primal-dual algorithm');
drawnow

% visualize deconvolution results along 1D profile line
figure; 
plot(0:255,f(round(end/2),:), 'b');
hold on;
plot(0:255,reconstruction_TV(round(end/2),:), 'r');
plot(0:255,u(round(end/2),:), 'black');
hold off;
xlim([0,255]);
legend('Blurred signal f', 'Reconstructed signal', 'Original signal u');
