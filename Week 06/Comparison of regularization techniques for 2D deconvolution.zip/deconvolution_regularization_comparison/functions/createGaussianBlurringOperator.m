function [convolutionOperation, convolutionOperation_adjoint, gaussianFilter_Fourier] = createGaussianBlurringOperator(size_I,hsize,sigma)

% Creates a operator for a blurring with a Gaussian kernel of size 
% 'hsize' and standard deviation 'sigma'

kernel = fspecial('gaussian', hsize, sigma);

gaussianFilter = zeros(size_I);
gaussianFilter(1:size(kernel,1),1:size(kernel,2)) = kernel;

% compute half width of kernel
halfwidth = floor(hsize/2);

% Center the kernel
gaussianFilter = circshift(gaussianFilter,-halfwidth,1);
gaussianFilter = circshift(gaussianFilter,-halfwidth,2);

% Precalculate FFT
gaussianFilter_Fourier = fftn(gaussianFilter);
gaussianFilter_Conjugated_Fourier = conj(gaussianFilter_Fourier);

% Setup the operators
convolutionOperation = @(x) ifftn(fftn(reshape(x,size_I)) .* gaussianFilter_Fourier);
convolutionOperation_adjoint = @(y) ifftn(fftn(reshape(y,size_I)) .* gaussianFilter_Conjugated_Fourier);

end