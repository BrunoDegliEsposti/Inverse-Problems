function div = div(I)
%I : vector field

%Divergence
n = size(I,1);
m = size(I,2);

tx = [n 1:n-1];
ty = [m 1:m-1];

divx         = I(:, :, 1) - I(tx, :, 1);
divx(1, :)   = I(1, :, 1);
divx(end, :) = -I(end-1, :, 1);
divy         = I(:, :, 2) - I(:,ty,2);
divy(:, 1)   = I(:, 1, 2);
divy(:, end) = -I(:, end-1, 2);
div = divx + divy;
