function u = deconv_TV_pd(f,kA,lambda)
% DECONV_TV_PD Performs image deconvolution of an image f by kernel kA 
% by iteratively
% computing a minimizer of the total variation L2 deocnvolution
% problem using Chambolle-Pock primal-dual optimization.
%
% Auxiliary function for the third exercise sheet of the lecture
% 'Mathematical image processing' in SS2016 at WWU Münster.
% authors: Camille Sutour, Daniel Tenbrinck
% last version: 07/07/16

% set stopping criterion
threshold = 1e-04;
max_iterations = 1000;

% Define convolution operator with convolution kernel kA in the Fourier domain
Conv_Op = @(x) ifft2(fft2(x) .* kA);
Conv_Op_adj = @(y) ifftn(fftn(y) .* conj(kA));

% initialize containers for iteration scheme
x_old = zeros(size(f));
x_bar = x_old;
y1 = grad(x_old);
y2 = Conv_Op(x_old);

% intialize container for energy values
energy = zeros(1,max_iterations);

% set primal and dual step size width
gamma = 0.35;
tau = 0.35;
% set relaxation parameter
theta = 1;

% generic definition of the proximal operators
prox_Fstar1 = @(y1) y1./max(abs(y1),1);
prox_Fstar2 = @(y2) (y2- gamma * f) /(1+gamma*lambda); 
prox_G = @(x) x;

% Initialization and computation of the energy
iteration = 1;
G = grad(f);
norm_G = sqrt(sum(G.^2,3)); % compute total variation of image
energy(1) =  1/2*sum(sum((x_old-f).^2)) + lambda*sum(sum(norm_G));
rel_change = Inf;

% iterate until maximal number of iterations are reached or convergence
while rel_change > threshold && iteration < max_iterations
  
  % increase iteration counter
  iteration = iteration + 1;
  
  % update dual variable
  y1 = prox_Fstar1(y1 + gamma*grad(x_bar));
  y2 = prox_Fstar2(y2 + gamma*Conv_Op(x_bar));

  % update primal variable
  x = prox_G(x_old - tau*(-div(y1) + Conv_Op_adj(y2)));
  
  % update relaxation variable
  x_bar = x + theta*(x-x_old);
  
  % compute relative change (only of primal variable)
  rel_change = norm(x(:) - x_old(:)) / norm(x(:));
  
  % compute total variation of u
  G = grad(x);
  norm_G = sqrt(G(:,:,1).^2+G(:,:,2).^2);
  
  % computate new energy value
  energy(iteration) = 1/2*sum(sum((Conv_Op(x)-f).^2)) + lambda*sum(sum(norm_G));
  
  % update primal variable
  x_old = x;
end

% restrict energy decrease to performed iterations
energy = energy(1:iteration);

% plot energy decrease for control
figure; plot(energy);

% set output variable
u = x;