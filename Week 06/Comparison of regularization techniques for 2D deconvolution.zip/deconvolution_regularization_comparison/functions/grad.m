function G = grad(I)

%Gradient
[n,m] = size(I);
dx = [2:n 1];
dy = [2:m 1];
G = cat(3, I(dx,:,:)-I, I(:,dy,:)-I);
G(end, :, 1) = 0;
G(:, end, 2) = 0;

